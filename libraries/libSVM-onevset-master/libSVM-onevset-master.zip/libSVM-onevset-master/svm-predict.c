/* Updated libsvm svm-predict to support open set recognition based on

   W. J. Scheirer, A.  Rocha, A. Sapkota, T. E. Boult, "Toward Open Set Recognition," IEEE Transactions on Pattern Analysis and Machine Intelligence, vol. 35, no. 7, pp. 1757-1772, July, 2013    

@article{10.1109/TPAMI.2012.256,
author = {W. J. Scheirer and A. Rocha and A. Sapkota and T. E. Boult},
title = {Toward Open Set Recognition},
journal ={IEEE Transactions on Pattern Analysis and Machine Intelligence},
volume = {35},
number = {7},
issn = {0162-8828},
year = {2013},
pages = {1757-1772},
doi = {http://doi.ieeecomputersociety.org/10.1109/TPAMI.2012.256},
}


If you use any of the open set functions please cite appropriately.

There are also extensions using libMR which will be described in other
publications and should also cite based on libMR licensing if that is used as well.


These open set extensions to libSVM are subject to the following

Copyright (c) 2010-2013  Regents of the University of Colorado and Securics Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following 3 conditions:

1) The above copyright notice and this permission notice shall be included in all
source code copies or substantial portions of the Software.

2) All documentation and/or advertising materials mentioning features or use of
this software must display the following acknowledgment:

      This product includes software developed in part at
      the University of Colorado Colorado Springs and Securics Inc.

3) Neither the name of Regents of the University of Colorado  and Securics Inc.  nor
 the names of its contributors may be used to endorse or promote products
 derived from this software without specific prior written permission.


THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


*/ 


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>
#include <glob.h>

#include "svm.h"


struct svm_node *x;
int max_nr_attr = 64;

struct svm_model* model;
int predict_probability=0;
double min_threshold = 0, max_threshold = 0;
bool min_set = false, max_set = false;
bool verbose=true;
int debug_level=0;

static char *line = NULL;
static int max_line_len;

//Open set stuff
bool open_set = false;
int nr_classes = 0;
double *lbl;

//score/vote output
bool output_scores = false;
bool output_total_scores = false;
bool output_votes = false;

#define Malloc(type,n) (type *)malloc((n)*sizeof(type))

static char* readline(FILE *input)
{
	int len;
	
	if(fgets(line,max_line_len,input) == NULL)
		return NULL;

	while(strrchr(line,'\n') == NULL)
	{
		max_line_len *= 2;
		line = (char *) realloc(line,(ulong)max_line_len);
		len = (int) strlen(line);
		if(fgets(line+len,max_line_len-len,input) == NULL)
			break;
	}
	return line;
}

void exit_input_error(int line_num)
{
	fprintf(stderr,"Wrong input format at line %d\n", line_num);
	exit(1);
}

void predict(FILE *input, FILE *output)
{
	int correct = 0;
	int reccorrect = 0;
        int OS_truereg=0;
        int OS_falsereg=0;
	int falsepos=0, falseneg=0, truepos=0, trueneg=0;
	int osfalsepos=0, osfalseneg=0, ostruepos=0, ostrueneg=0;

	int total = 0;
	double error = 0;
	double sump = 0, sumt = 0, sumpp = 0, sumtt = 0, sumpt = 0;



	int svm_type, nr_class, ktype;
        svm_type = svm_get_svm_type(model);
        nr_class = svm_get_nr_class(model);
        ktype= model->param.kernel_type;
	printf("\nSVM Type %d, Kernel Type %d,  Num Classes %d \n",svm_type, ktype, nr_class );	

	double *prob_estimates=NULL;
	int j;

	if(predict_probability && !open_set)
	{
		if (svm_type==NU_SVR || svm_type==EPSILON_SVR)
			printf("Prob. model for test data: target value = predicted value + z,\nz: Laplace distribution e^(-|z|/sigma)/(2sigma),sigma=%g\n",svm_get_svr_probability(model));
		else
		{
			int *labels=(int *) malloc(nr_class*sizeof(int));
			svm_get_labels(model,labels);
			prob_estimates = (double *) malloc(nr_class*sizeof(double));
			fprintf(output,"labels");		
			for(j=0;j<nr_class;j++)
				fprintf(output," %d",labels[j]);
			fprintf(output,"\n");
			free(labels);
		}
	}

	max_line_len = 1024;
	line = (char *)malloc(max_line_len*sizeof(char));
	while(readline(input) != NULL)
	{
		int i = 0;
		double target_label, predict_label = 0;
		char *idx, *val, *label, *endptr;
		int inst_max_index = -1; // strtol gives 0 if wrong format, and precomputed kernel has <index> start from 0

		label = strtok(line," \t\n");
		if(label == NULL) // empty line
			exit_input_error(total+1);

		target_label = strtod(label,&endptr);
                //printf("Target Label %lf\n",target_label);
		if(endptr == label || *endptr != '\0')
			exit_input_error(total+1);

		while(1)
		{
			if(i>=max_nr_attr-1)	// need one more for index = -1
			{
				max_nr_attr *= 2;
				x = (struct svm_node *) realloc(x,max_nr_attr*sizeof(struct svm_node));
			}

			idx = strtok(NULL,":");
			val = strtok(NULL," \t");

			if(val == NULL)
				break;
			errno = 0;
			x[i].index = (int) strtol(idx,&endptr,10);
			if(endptr == idx || errno != 0 || *endptr != '\0' || x[i].index <= inst_max_index)
				exit_input_error(total+1);
			else
				inst_max_index = x[i].index;

			errno = 0;
			x[i].value = strtod(val,&endptr);
			if(endptr == val || errno != 0 || (*endptr != '\0' && !isspace(*endptr)))
				exit_input_error(total+1);

			++i;
		}
		x[i].index = -1;

		if (predict_probability && (svm_type==C_SVC || svm_type==NU_SVC))
		{
			predict_label = svm_predict_probability(model,x,prob_estimates);
			fprintf(output,"%g",predict_label);
			for(j=0;j<nr_class;j++)
				fprintf(output," %g",prob_estimates[j]);
			fprintf(output,"\n");
		}
		else if (svm_type==ONE_VS_REST_PIESVM)
		{  //wsvm one-vs-rest	
			int *votes = NULL;
			double **scores = Malloc(double *, nr_class+1);
                        votes = Malloc(int,nr_class+1);
			for(int v=0; v<nr_class; v++)
			{
				scores[v] = Malloc(double, nr_class);
                                memset(scores[v],0,nr_class*sizeof(double));
			}
			predict_label = svm_predict_extended(model,x, scores, votes);

                        fprintf(output,"%g",predict_label);

                        if(predict_label== target_label ) {
                          if(! (model->param.neg_labels==false && target_label>=0)){
                            reccorrect++;
                          }
                        }

                        int labfound=0;
                        for(int v=0; v<nr_class; v++)
                          if(target_label == model->label[v]) labfound=1;
                        
                        if(predict_label == model->param.rejectedID){
                          if(labfound)  OS_falsereg++;
                            else OS_truereg++;
                        }



                        for(int v=0; v<nr_class; v++){
                          //                          fprintf(stderr,"Try for %d (lab %d) with ",v,model->label[v]);
                          if(model->param.neg_labels==false && model->label[v]<0 ) continue;
                          //                          fprintf(stderr,"%g (!= %g)\n",predict_label, target_label);
                          if(scores[v][0] <0 && model->label[v] != target_label ) ostrueneg += nr_class;
                          if(scores[v][0] >=0 && model->label[v] != target_label ) osfalsepos+= nr_class;
                          if(scores[v][0] >=0 && model->label[v] == target_label) ostruepos+= nr_class;
                          if(scores[v][0] < 0 && model->label[v] == target_label) osfalseneg+= nr_class;
                        }

			if(output_scores || output_votes || output_total_scores)
			{
                          if(predict_label== target_label) fprintf(output," (== %g)", target_label);
                          else fprintf(output," (!= %g)",target_label);
				if(output_votes)
				{
					for(int v=0; v<nr_class; v++)
                                          fprintf(output," %d:%d", model->label[v],votes[v]);
				}
				if(output_scores)
				{
                                  for(int v=0; v<nr_class; v++){
                                          fprintf(output," %d:%g", model->label[v], scores[v][0]);
                                                            }
				}
				if(output_total_scores)
				{
					for(int v=0; v<nr_class; v++)
                                          fprintf(output,"  %d:%g", model->label[v], scores[v][0]);
				}
				fprintf(output,"\n");
			}			
                        else
			{
				fprintf(output,"\n");
			}

                        if(model->nr_class <= 2){
                          predict_label = (predict_label>=0)?1:-1;
                        }
                        

			if(predict_label == target_label){
				++correct; 
				if(predict_label > 0) ++truepos;
				else ++trueneg;
			} else {
				if(predict_label > 0) ++falsepos; 
				else ++ falseneg;
                                } 



			
			//cleanup scores and votes
			for(int v=0; v<model->nr_class; v++)
                          if(scores[v] != NULL)
                            free(scores[v]);
			if(scores != NULL)
                          free(scores);
			if(votes != NULL)
                          free(votes);
                        
                        // count per class correct/false 
                        /*if (predict_label == target_label)   {
                            ++correct; ++truepos;
                          } else {
                            ++falsepos;
                          }*/
                        //
		}
		else if (svm_type==PAIR_PIESVM)
		{
			int *votes = NULL;
			double **scores = Malloc(double *, nr_class);
			for(int v=0; v<nr_class; v++)
			{
				scores[v] = Malloc(double, nr_class);
				for(int z=0; z<(nr_class-1); z++)
					scores[v][z] = 0;
			}
			predict_label = svm_predict_extended(model,x, scores, votes);
                        fprintf(output,"%g",predict_label);
			//printf("n*n-1 scores matrix\n");
			for(int ii=0;ii<nr_class;ii++){
				for(int jj=0;jj<nr_class;jj++){
					if(ii==jj)
						continue;
					if(verbose && debug_level>0) printf("%lf\t",scores[ii][jj]);
				}
				//printf("\n");
			}
                        if(verbose && debug_level>0) 			printf("\n");
                        if(predict_label== target_label) {
                          if(! (model->param.neg_labels==false && target_label>=0)){
                            reccorrect++;
                          }
                        }

                        int labfound=0;
                        for(int v=0; v<nr_class; v++)
                          if(target_label == model->label[v]) labfound=1;
                        
                        if(predict_label == model->param.rejectedID){
                          if(labfound)  OS_falsereg++;
                            else OS_truereg++;
                        }


			if(output_scores || output_votes || output_total_scores)
			{
                          if(predict_label== target_label) fprintf(output," (== %g)", target_label);
                          else fprintf(output," (!= %g)",target_label);
				if(output_votes)
				{
					for(int v=0; v<nr_class; v++)
						fprintf(output," %d", votes[v]);
				}
				if(output_scores)
				{
					for(int v=0; v<nr_class; v++)
						for(int z=0; z<nr_class; z++)
							if(v != z)
								fprintf(output," %d-%d:%g", v+1, z+1, scores[v][z]);
				}
				if(output_total_scores)
				{
					double *total_scores = Malloc(double, nr_class);
					for(int v=0; v<nr_class; v++)
						total_scores[v] = 0;
					for(int v=0; v<nr_class; v++)
						for(int z=0; z<nr_class; z++)
							total_scores[v] += scores[v][z];
					for(int v=0; v<nr_class; v++)
						fprintf(output," %g", total_scores[v]);
					free(total_scores);				
				}
				fprintf(output,"\n");
			}
			else
			{
                          fprintf(output,"\n");
			}
			

			if(model->param.svm_type == ONE_CLASS || 
			   ((model->param.svm_type == 0) && nr_class <= 2) )
				predict_label = (predict_label>0)?1:-1;

                        // get openset estimates for regular stuff
                        
                        for(int v=0; v<nr_class; v++){
                          for(int j=0; j<nr_class; j++){
                          //                          fprintf(stderr,"Try for %d (lab %d) with  score %g and ",v,model->label[v],scores[v][0]);
                          //                          if(model->param.neg_labels==false && model->label[v]<0 ) continue;
                          //                          fprintf(stderr,"%g (!= %g) \n",predict_label, target_label);
                          if(scores[v][j] <0 && model->label[v] != target_label ) ++ostrueneg;
                          if(scores[v][j] >=0 && model->label[v] != target_label ) ++osfalsepos;
                          if(scores[v][j] >=0 && model->label[v] == target_label) ++ostruepos;
                          if(scores[v][j] < 0 && model->label[v] == target_label) ++osfalseneg;
                          }
                        }
                        

			if(predict_label == target_label){
				++correct; 
				if(predict_label > 0) ++truepos;
				else ++trueneg;
			} else {
				if(predict_label > 0) ++falsepos; 
				else ++ falseneg;
                                } 

			//cleanup scores and votes
			for(int v=0; v<model->nr_class; v++)
				if(scores[v] != NULL)
					free(scores[v]);
			if(scores != NULL)
				free(scores);
			if(votes != NULL)
				free(votes);

		} 
		else  if (!open_set || svm_type==OPENSET_PAIR)
		{
			int *votes = NULL;
			double **scores = Malloc(double *, nr_class+1);
			for(int v=0; v<nr_class; v++)
			{
				scores[v] = Malloc(double, nr_class);
				for(int z=0; z<nr_class; z++)
					scores[v][z] = 0;
			}
			predict_label = svm_predict_extended(model,x, scores, votes);
                        fprintf(output,"%g",predict_label);
                        if(predict_label== target_label) {
                          if(! (model->param.neg_labels==false && target_label>=0)){
                            reccorrect++;
                          }
                        }

                        int labfound=0;
                        for(int v=0; v<nr_class; v++)
                          if(target_label == model->label[v]) labfound=1;
                        
                        if(predict_label == model->param.rejectedID){
                          if(labfound)  OS_falsereg++;
                            else OS_truereg++;
                        }


			if(output_scores || output_votes || output_total_scores)
			{
                          if(predict_label== target_label) fprintf(output," (== %g)", target_label);
                          else fprintf(output," (!= %g)",target_label);
				if(output_votes)
				{
					for(int v=0; v<nr_class; v++)
						fprintf(output," %d", votes[v]);
				}
				if(output_scores)
				{
					for(int v=0; v<nr_class; v++)
						for(int z=0; z<nr_class; z++)
							if(v != z)
								fprintf(output," %d-%d:%g", v+1, z+1, scores[v][z]);
				}
				if(output_total_scores)
				{
					double *total_scores = Malloc(double, nr_class);
					for(int v=0; v<nr_class; v++)
						total_scores[v] = 0;
					for(int v=0; v<nr_class; v++)
						for(int z=0; z<nr_class; z++)
							total_scores[v] += scores[v][z];
					for(int v=0; v<nr_class; v++)
						fprintf(output," %g", total_scores[v]);
					free(total_scores);				
				}
				fprintf(output,"\n");
			}
			else
			{
                          fprintf(output,"\n");
			}
			

			if(model->param.svm_type == ONE_CLASS || 
			   ((model->param.svm_type == 0) && nr_class <= 2) )
				predict_label = (predict_label>0)?1:-1;

                        // get openset estimates for regular stuff
                        
                        for(int v=0; v<nr_class; v++){
                          for(int j=0; j<nr_class; j++){
                          //                          fprintf(stderr,"Try for %d (lab %d) with  score %g and ",v,model->label[v],scores[v][0]);
                          //                          if(model->param.neg_labels==false && model->label[v]<0 ) continue;
                          //                          fprintf(stderr,"%g (!= %g) \n",predict_label, target_label);
                          if(scores[v][j] <0 && model->label[v] != target_label ) ++ostrueneg;
                          if(scores[v][j] >=0 && model->label[v] != target_label ) ++osfalsepos;
                          if(scores[v][j] >=0 && model->label[v] == target_label) ++ostruepos;
                          if(scores[v][j] < 0 && model->label[v] == target_label) ++osfalseneg;
                          }
                        }
                        

			if(predict_label == target_label){
				++correct; 
				if(predict_label > 0) ++truepos;
				else ++trueneg;
			} else {
				if(predict_label > 0) ++falsepos; 
				else ++ falseneg;
                                } 

			//cleanup scores and votes
			for(int v=0; v<model->nr_class; v++)
				if(scores[v] != NULL)
					free(scores[v]);
			if(scores != NULL)
				free(scores);
			if(votes != NULL)
				free(votes);

		}   else 
		{  //open set	
			//printf("Hello1\n");
			int *votes = NULL;
			double **scores = Malloc(double *, nr_class+1);
                        votes = Malloc(int,nr_class+1);
			for(int v=0; v<nr_class; v++)
			{
				scores[v] = Malloc(double, nr_class);
                                memset(scores[v],0,nr_class*sizeof(double));
			}
			//double scores = Malloc(double, nr_class+1);
			//for(int v=0; v<nr_class; v++)
			//	scores[v] = 0;
			predict_label = svm_predict_extended(model,x, scores, votes);
			//printf("Scores to prob\n");
		        //for(int j=0;j<model->openset_dim;j++)
	  		//	printf("%lf\t",scores[j][0]);
	  		//printf("\n");	
			//printf("Hello3\n");
			
                        fprintf(output,"%g",predict_label);

                        if(predict_label== target_label ) {
                          if(! (model->param.neg_labels==false && target_label>=0)){
                            reccorrect++;
                          }
                        }

                        int labfound=0;
                        for(int v=0; v<nr_class; v++)
                          if(target_label == model->label[v]) labfound=1;
                        
                        if(predict_label == model->param.rejectedID){
                          if(labfound)  OS_falsereg++;
                            else OS_truereg++;
                        }



                        for(int v=0; v<nr_class; v++){
                          //                          fprintf(stderr,"Try for %d (lab %d) with ",v,model->label[v]);
                          if(model->param.neg_labels==false && model->label[v]<0 ) continue;
                          //                          fprintf(stderr,"%g (!= %g)\n",predict_label, target_label);
                          if(scores[v][0] <0 && model->label[v] != target_label ) ostrueneg += nr_class;
                          if(scores[v][0] >=0 && model->label[v] != target_label ) osfalsepos+= nr_class;
                          if(scores[v][0] >=0 && model->label[v] == target_label) ostruepos+= nr_class;
                          if(scores[v][0] < 0 && model->label[v] == target_label) osfalseneg+= nr_class;
                        }

			if(output_scores || output_votes || output_total_scores)
			{
                          if(predict_label== target_label) fprintf(output," (== %g)", target_label);
                          else fprintf(output," (!= %g)",target_label);
				if(output_votes)
				{
					for(int v=0; v<nr_class; v++)
                                          fprintf(output," %d:%d", model->label[v],votes[v]);
				}
				if(output_scores)
				{
                                  for(int v=0; v<nr_class; v++){
                                          fprintf(output," %d:%g", model->label[v], scores[v][0]);
                                                            }
				}
				if(output_total_scores)
				{
					for(int v=0; v<nr_class; v++)
                                          fprintf(output,"  %d:%g", model->label[v], scores[v][0]);
				}
				fprintf(output,"\n");
			}			
                        else
			{
				fprintf(output,"\n");
			}

                        if(model->nr_class <= 2){
                          predict_label = (predict_label>=0)?1:-1;
                        }
                        

			if(predict_label == target_label){
				++correct; 
				if(predict_label > 0) ++truepos;
				else ++trueneg;
			} else {
				if(predict_label > 0) ++falsepos; 
				else ++ falseneg;
                                } 



			
			//cleanup scores and votes
			for(int v=0; v<model->nr_class; v++)
                          if(scores[v] != NULL)
                            free(scores[v]);
			if(scores != NULL)
                          free(scores);
			if(votes != NULL)
                          free(votes);
                        
			
                        // count per class correct/false 
                        /*if (predict_label == target_label)   {
                            ++correct; ++truepos;
                          } else {
                            ++falsepos;
                          }*/
                        //
		}
		error += (predict_label-target_label)*(predict_label-target_label);
		sump += predict_label;
		sumt += target_label;
		sumpp += predict_label*predict_label;
		sumtt += target_label*target_label;
		sumpt += predict_label*target_label;
		++total;
	}

	if (svm_type==NU_SVR || svm_type==EPSILON_SVR )
	{
		printf("Mean squared error = %g (regression)\n",error/total);
		printf("Squared correlation coefficient = %g (regression)\n",
		       ((total*sumpt-sump*sumt)*(total*sumpt-sump*sumt))/
		       ((total*sumpp-sump*sump)*(total*sumtt-sumt*sumt))
		       );
	}
	else
	{
		if(nr_classes > 1) 
            printf("Classification (Multi-class Recognition)  Rate = %g%% (%d/%d)\n",
				   (double)correct/total*100,correct,total);
		else             printf("Classification Accuracy = %g%% (%d/%d)\n",
								(double)correct/total*100,correct,total);

		if(open_set || verbose || (truepos+falsepos >0)){
			if ( (truepos+falsepos) > 0){
				double precision = ((double) (truepos)/(truepos+falsepos));
				double recall = 0;
				if((truepos + falseneg) > 0) recall = ((double) truepos)/(truepos + falseneg);
				double fmeasure = 0;
				if( (precision + recall > 0)) fmeasure = 2* precision*recall/(precision + recall);
				printf("  Precision=%lf,   Recall=%lf   Fmeasure=%lf\n",precision, recall, fmeasure);
				if(verbose)               
					printf("   Total tests=%d, True pos %d True Neg %d, False Pos %d, False neg %d\n",
						   truepos+ trueneg+ falsepos+ falseneg, truepos, trueneg, falsepos, falseneg);
			} else if(((truepos+falsepos)==0)){
				printf("  Precision=0,   Recall=0   Fmeasure=0\n");
            }
			if ( (ostruepos+osfalsepos) > 0){
				double precision = ((double) (ostruepos)/(ostruepos+osfalsepos));
				double recall = 0;
				if((ostruepos + osfalseneg) > 0) recall = ((double) ostruepos)/(ostruepos + osfalseneg);
				double fmeasure = 0;
				if( (precision + recall > 0)) fmeasure = 2* precision*recall/(precision + recall);
                                if(verbose)               
					printf("   Total Pairwise tests=%d, True pos %d True Neg %d, False Pos %d, False neg %d\n",
						   ostruepos+ ostrueneg+ osfalsepos+ osfalseneg, ostruepos, ostrueneg, osfalsepos, osfalseneg);
				printf("  Pairwise Precision=%lf,   Recall=%lf   Fmeasure=%lf\n",precision, recall, fmeasure);
			
			} else if(((ostruepos+osfalsepos)==0))
				printf("  Pariwise Precision=0,   Recall=0   Fmeasure=0\n");
                        if(reccorrect >0) {
				printf("Multiclass Recognition Rate   =   %g%% (%d/%d)\n",
					   (double)100*reccorrect/(total),reccorrect,total );
				printf("Multiclass Recognition Recall  =   %g%% (%d/%d)\n\n",
					   (double)ostruepos/(ostruepos+osfalseneg)* 100,ostruepos,ostruepos+osfalseneg );
                        }
                        if(OS_truereg+ OS_falsereg>0)
                          printf("Unknown classes true rejections %d, False rejections %d\n\n",
                                 OS_truereg, OS_falsereg );
		}
	}

	if(predict_probability)
		free(prob_estimates);
}

void exit_with_help()
{
	printf(
	"Usage: svm-predict [options] test_file model_file output_file\n"
	"options:\n"
	"  -b probability_estimates: whether to predict probability estimates, 0 or 1 (default 0); for one-class SVM only 0 is supported\n"
        "  -o: this is an open set problem. this will look for model files with names of the form <model_file>.<class>\n"
        "  -V  for more verbose output\n"
	"  -s output scores in bin format(1-2, 1-3, 1-4, 2-3) to outputfile(cannot be combined with -v or -t) \n"
	"  -t output totaled scores 1-2+1-3+1-4=1 ect to outputfile(cannot be combined with -s or -v) \n"
	"  -v output votes to outputfile(cannot be combined with -s or -t) \n"
	);
	exit(1);
}

int main(int argc, char **argv)
{
	FILE *input, *output;
	int i;
        double openset_min_probability=.001;

	// parse options
	for(i=1;i<argc;i++)
	{
		if(argv[i][0] != '-') break;
		switch(argv[i][1])
		{
                case 'b':
                  predict_probability = atoi(argv[++i]);
                  break;
                case 'P':
                  openset_min_probability = atof(argv[++i]);
                  break;
                case 'o':
                  open_set = true;
                  break;
                case 'V':
                  verbose = true;
                  break;
				case 's':
					output_scores = true;
					break;
				case 'a':
					output_scores = true;
					output_votes = true;
					output_total_scores = true;
					break;
				case 't':
					output_total_scores = true;
					break;
				case 'v':
					output_votes = true;
					break;
                default:
                  fprintf(stderr,"Unknown option: -%c\n", argv[i][1]);
                  exit_with_help();
		}
	}
	if(i>argc-2)
		exit_with_help();
        /*
	if( (output_scores && output_total_scores && output_votes) ||
		(output_scores && output_total_scores) ||
		(output_scores && output_votes) ||
		(output_total_scores && output_votes) ||
		(output_total_scores && output_scores) )
	{
		fprintf(stderr, "cannot output more than one(scores,totalscores,votes),"
				" defaulting to total scores \n");
		output_votes=false;
		output_scores=false;
	}
	*/

	input = fopen(argv[i],"r");
	if(input == NULL)
	{
		fprintf(stderr,"can't open input file %s\n",argv[i]);
		exit(1);
	}

	output = fopen(argv[i+2],"w");
	if(output == NULL)
	{
		fprintf(stderr,"can't open output file %s\n",argv[i+2]);
		exit(1);
	}


        if((model=svm_load_model(argv[i+1]))==0)
          {
            fprintf(stderr,"can't open model file %s\n",argv[i+1]);
            exit(1);
          } 
        model->param.openset_min_probability = openset_min_probability;
        if(model && (model->param.svm_type == OPENSET_OC || model->param.svm_type == OPENSET_BIN || model->param.svm_type == OPENSET_PAIR ||model->param.svm_type == ONE_VS_REST_PIESVM )) open_set=true;

	x = (struct svm_node *) malloc(max_nr_attr*sizeof(struct svm_node));
	if(predict_probability && !open_set)
	{
		if(svm_check_probability_model(model)==0)
		{
			fprintf(stderr,"Model does not support probabiliy estimates\n");
			exit(1);
		}
	}
	else if (!open_set)
	{
		if(svm_check_probability_model(model)!=0)
			printf("Model supports probability estimates, but disabled in prediction.\n");
	}
	predict(input,output);

        svm_free_and_destroy_model(&model);

	free(x);
	free(line);
	fclose(input);
	fclose(output);
	return 0;
}
